// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
// import "@hotwired/turbo-rails"
// import "controllers"

console.log('i am worried 1')
import "main.js";
import "background-video.js"
console.log('i am worried 2');
